<?php
	$koneksi=mysql_connect("localhost","mitratoy","Hijrah*12");
	$db=mysql_select_db("mitratoy_webmti1");
?>