<img src="../logo transparent.png" width="179" height="103" />
<br/>
<h3>
	Mitra Toyotaka Indonesia
</h3>
<table width="966" align="center" cellpadding="0" cellspacing="0" border="0">
  <tr>
        <td>
        <p align="justify">
          PT. Mitra Toyotaka Indonesia selanjutnya disingkat menjadi PT. MTI adalah sebuah perusahaan Join Venture dengan status penanaman modal asing antara PT. Toyota Sangyo Corporation (Japan), meiwa Industri Corporation(Japan), dan Toyota Kagaku Co.Ltd (Japan). <br/><br /> 
          PT. Mitra Toyotaka Indonesia didirikan pada tanggal 6 Februari 1990 dan Akta Notaris Nomor 6, tanggal 6 Februari 1990 yang berlokasi di Jl. Raya Serang Km. 24 Balaraja Tanggerang Provinsi Banten dan mulai berproduksi pada bulan februari 1991 dengan luas area 31.140 M2 dan luas bangunan 14.000 M2 dengan jumlah karyawan perbulan agustus 2012 sebanyak 449 orang.<br/><br />
          PT. Mitra Toyotaka Indonesia merupakan perusahaan yang bergerak dibidang manufacturing dengan menggunakan bahan baku steel dengan bidang usaha sebagai berikut :</p>
        </td>
      <tr>
      	<td colspan="2"><br/>
		<ol>
		  <li>Bidang Steel Case<br align="justify" />
		    <br />
		    - steel Case for Automotive Part (Returnable rack, Special Pallet & special cart for material handling factory, etc)<br />
		    - Customize special design in steel pallet, steel rack & cart<br />
		    - Press Part<br />
		    </li>
            <br/>
          <li>
            Auto Body Truck<br />
            - Wing Box (Quick Roof)
            - Special Car<br />
            - Steel Box<br />
            - Flat Deck<br />
            - Concrete Mixer<br />
          </li>
      </ol>
		<blockquote>
		  <p>	      PT. Mitra Toyotaka Indonesia adalah sebuah perusahaan penanaman modal asing (jepang) yang telah berdiri sejak 6 Februari 1990. aktifitas kami
		    berada dikawasan industri balaraja - Tanggerang provinsi banten dengan bisnis utama kami dibidang Industrial Steel Case and Pallet Component dan Carrosserie.<br>
		    Berbekal Pengalaman yang panjang dan sumber daya manusia yang handal, serta penerapan manajemen mutu ISO 9001:2000, kami siap memasuki era persaingan bebas. komitmen kami adalah maju bersama sejalan dengan perkembangan ekonomi dan bisinis dunia.
		    </font>
		    </p>
	    </blockquote></td>
  </tr>
</table>
</div></div>