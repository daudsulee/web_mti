<section id="contact">
<div class="row">
	<div class="col-md-8 col-md-offset-2 text-center">
		<h2 class="section-heading">CORPORATE<b> IDENTITY</b></h2>
		<hr class="primary">
		
	</div>
</div>
</div>
<div class="container">
<div class="row">
	<!-- begin 1st row -->
	<div class="col-md-8 text-left">
			<h4><marquee><b><em></em></b></marquee></h4>
			<div class="dots blogdots">
			</div>
			<p style=" text-align: left;">
				 <h2><b>Mission</b></h2> 
                 We Shall :
			</p>
			<p>
				 1. &nbsp; Contribute to customers and societies through supply of cargo-transportation 
							and material handling &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;equipment. <br/>
                 2. &nbsp; Pursue happiness for all employees and family.<br/>
                 3. &nbsp; Continue pursuing the best quality, services of our wing box brand “Quick Roof”.<br/>
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  And it is our pride to be trusted by all stakeholders through achieving our corporate mission

			</p>
            <br/>
			<p>
				<h2><b>Management Policy</b></h2> 
                We Shall :
			</p>
            <p>
				 1. &nbsp; Stay hungry for innovation by TPS related Kaizen approach. <br/>
                 2. &nbsp; Focus the trend and set our sail to catch a big wind.<br/>
                 3. &nbsp; Execute with fanatical discipline.<br/>
                 4. &nbsp; Dominate, saturated and do what it takes to be a major player.<br/>
                 5. &nbsp; Surround ourselves with our stakeholders and build a culture driven by value.<br/>
                 
			</p>
            <br/>
			<p>
				<h2><b>Principle Attitude</b></h2> 
                We Shall :
			</p>
            <p>
				 1. &nbsp; Comply with public and company discipline to keep social order. <br/>
                 2. &nbsp; Dedicate ourselves to safety operation and high quality performance.<br/>
                 3. &nbsp; Place integrity, passion, humility and team-work.<br/>
                 4. &nbsp; Judged by job facts and actual existing.<br/>
                
			</p>
           
	</div>
	<div class="col-md-4 text-left">
		<div class="service-box">
			<img src="gambar/iso.jpg" width="70%">
			<br class="clear"/>
		
		</div>
	</div>
</section>