
<section id="contact">
<div class="row">
	<div class="col-md-8 col-md-offset-2 text-center">
		<h2 class="section-heading">MY<b> CONTACT</b></h2>
		<hr class="primary">
		
	</div>
</div>
</div>
<div class="container">
<div class="row">
	<!-- begin 1st row -->
	<div class="col-md-8 text-left">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1800.9863256311307!2d106.45851497303826!3d-6.192087601262278!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e42017146e4da5f%3A0x3364f3c39886b5a1!2sToyotaka+Mitra+Indonesia.+PT!5e1!3m2!1sen!2sid!4v1515003141762" width="750" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
	<div class="col-md-4 text-left">
		<div class="service-box">
			<h3 >Head Office :</h3>
            
			<p>
				 Jl. RAYA SERANG KM 24, BALARAJA - TANGERANG
						BANTEN - INDONESIA  15610 <br/> 
						Phone : +62 21 5951624 / Fax: +62 21 5951623   </br>
						www.mitratoyotaka.co.id  <br/>
						Contact : Adelia Winasari <br/>
                        Email :sales.admin@mitratoyotaka.co.id<br />
                        No HP : +6282210780162
			</p>
            <br/>
            <h3>Display Area at Karawang Branch :</h3>
            <p>
            Jl. Raya Klari Km. 10<br/>
			Dsn. KLAPA NUNGGAL, Ds.  GINTUNG KERTA,<br/> Kec. KLARI, 
			Kab. KARAWANG, <br/>JAWA BARAT - INDONESIA <br/>
			Contact : Windy Wahyuni <br/>
			Email : sales.karawang@mitratoyotaka.co.id <br />
			No HP : +62895396895442
            </p>
			
			<br class="clear"/>
		
		</div>
	</div>
</section>
<!-- Section Social
================================================== -->
<section id="social" class="parallax parallax-image" style="background-image:url(https://s3-eu-west-1.amazonaws.com/layanademo/s3-min.jpg);">
<div class="overlay" style="background:#222;opacity:0.5;">
</div>
<div class="wrapsection">
<div class="container">
	<div class="parallax-content">
		<div class="row wow fadeInLeft">
			<div class="col-md-3">
				<div class="funfacts text-center">
					<div class="icon">
						<a href="#"><i class="fa fa-twitter"></i></a>
					</div>
					<h4>Twitter</h4>
				</div>
			</div>
			<div class="col-md-3">
				<div class="funfacts text-center">
					<div class="icon">
						<a href="https://www.facebook.com/MitraToyotakaIndonesia/"><i class="fa fa-facebook"></i></a>
					</div>
					<h4>Facebook</h4>
				</div>
			</div>
			<div class="col-md-3">
				<div class="funfacts text-center">
					<div class="icon">
						<a href="#"><i class="fa fa-google"></i></a>
					</div>
					<h4>Google</h4>
				</div>
			</div>
			<div class="col-md-3">
				<div class="funfacts text-center">
					<div class="icon">
						<a href="#"><i class="fa fa-wordpress"></i></a>
					</div>
					<h4>Blog</h4>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</section>
<div class="clearfix">
</div>